"use strict"

let canvas, ctx;

const init = () => {
  canvas = document.querySelector('#demo');
  ctx = canvas.getContext('2d');
  
  ctx.fillStyle = 'white';
  ctx.clearRect(0,0,canvas.width,canvas.height);
  
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';
  ctx.font = '15pt Courier';
  ctx.fillText('Test Canvas';
  
  canvas.width/2,canvas.height/2);
};

window.onload = init;